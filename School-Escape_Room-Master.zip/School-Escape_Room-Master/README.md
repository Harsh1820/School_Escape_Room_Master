# School-Escape Room

This is a unity project a colleague and I made as a School project for our final class.

This project is intendet to be used as a tool for senior's (*students of 10th-12th class*) to better understand and more interactively learn the basic concepts of calculus.

---

The Unity project is layouted to be used on tablets or touch-screen devices.  
Due to that nature We implemented our own dynamic touch screen keyboard, which depending on the answer dynamically switches to a numerical/letter based keyboard.  
This implementation often leads to warnings issued by Unity, to be cautious not to enter critical data. That can be disregarded since in this project You are never intended to enter critical data.

***Yes***, We are aware that Unity has an in build touch screen keyboard functionality, which uses the deployed OS specific keyboard.  
Unfortunately, We had to deploy our project on [itch.io](https://jannickh.itch.io/mathematische-schatzsuche) since We didn't had administrated access to the school's ipads at that time.  
Therefor, We needed to implement the keyboard ourself since the build in keyboard doesn't work when deployed on [itch.io](https://jannickh.itch.io/mathematische-schatzsuche).

---

Unfortunately, the Story and the questions are completely in german.

---

Link to the project on itch.io: https://jannickh.itch.io/mathematische-schatzsuche
