public enum KeyboardMode {
    numbers,
    hex,
    bin
}